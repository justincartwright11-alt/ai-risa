# Report Bundle: matchup_fighter_belal_muhammad_vs_fighter_gabriel_bonfim__s2.0

**Version:** v100-template-standardized

**Export Timestamp:** 2026-04-09T05:38:37.856237

## Artifact Inventory
- json: matchup_fighter_belal_muhammad_vs_fighter_gabriel_bonfim__s2.0__Premium_Fight_Intelligence_Brief__v100-template-standardized.json
- markdown: matchup_fighter_belal_muhammad_vs_fighter_gabriel_bonfim__s2.0__Premium_Fight_Intelligence_Brief__v100-template-standardized.md
- pdf: matchup_fighter_belal_muhammad_vs_fighter_gabriel_bonfim__s2.0__Premium_Fight_Intelligence_Brief__v100-template-standardized.pdf
- manifest: manifest.json
- assets: C:\ai_risa_data\deliveries\v100-template-standardized\matchup_fighter_belal_muhammad_vs_fighter_gabriel_bonfim__s2.0\assets
- checksums: checksums.txt

## How to Use
See manifest.json for artifact details. Use checksums.txt to verify integrity.
All filenames are deterministic and versioned.
