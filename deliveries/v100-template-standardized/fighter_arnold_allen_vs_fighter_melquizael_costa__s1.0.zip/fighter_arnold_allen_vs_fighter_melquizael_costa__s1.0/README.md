# Report Bundle: fighter_arnold_allen_vs_fighter_melquizael_costa__s1.0

**Version:** v100-template-standardized

**Export Timestamp:** 2026-04-09T05:38:37.801729

## Artifact Inventory
- json: fighter_arnold_allen_vs_fighter_melquizael_costa__s1.0__Premium_Fight_Intelligence_Brief__v100-template-standardized.json
- markdown: fighter_arnold_allen_vs_fighter_melquizael_costa__s1.0__Premium_Fight_Intelligence_Brief__v100-template-standardized.md
- pdf: fighter_arnold_allen_vs_fighter_melquizael_costa__s1.0__Premium_Fight_Intelligence_Brief__v100-template-standardized.pdf
- manifest: manifest.json
- assets: C:\ai_risa_data\deliveries\v100-template-standardized\fighter_arnold_allen_vs_fighter_melquizael_costa__s1.0\assets
- checksums: checksums.txt

## How to Use
See manifest.json for artifact details. Use checksums.txt to verify integrity.
All filenames are deterministic and versioned.
